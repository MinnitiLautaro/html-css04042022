Brian, espero estes bien. 
Te paso esta actividad de cv. Me parece que aprendi un monton sobre la marcha pero cada vez se me hace mas cuesta arriba.
Me gustaria que me orientes un poco con respecto al orden que le debo dar a las cosas (algun tip) y algun consejo con respecto a los selectores y como establecer un orden con estos.